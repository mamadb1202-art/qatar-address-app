# Release builds currently ship without minification.
# Keep WebView JS bridges if minify is enabled later.
-keepclassmembers class qa.inwani.address.** {
    @android.webkit.JavascriptInterface <methods>;
}
