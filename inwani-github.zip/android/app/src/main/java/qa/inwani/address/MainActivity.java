package qa.inwani.address;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String START_URL =
            "https://appassets.androidplatform.net/assets/public/index.html";
    private static final String QARS_HOST = "khazna.gisqatar.org.qa";

    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(webView);

        final WebViewAssetLoader assetLoader =
                new WebViewAssetLoader.Builder()
                        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                        .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(
                new WebViewClient() {
                    @Override
                    public WebResourceResponse shouldInterceptRequest(
                            WebView view, WebResourceRequest request) {
                        Uri url = request.getUrl();
                        if (QARS_HOST.equals(url.getHost())) {
                            return nativeFetch(request);
                        }
                        return assetLoader.shouldInterceptRequest(url);
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(
                            WebView view, WebResourceRequest request) {
                        Uri uri = request.getUrl();
                        String host = uri.getHost() == null ? "" : uri.getHost();
                        if (APP_HOST.equals(host)) {
                            return false;
                        }
                        String scheme = uri.getScheme();
                        if ("https".equals(scheme)
                                || "http".equals(scheme)
                                || "geo".equals(scheme)
                                || "waze".equals(scheme)
                                || "google.navigation".equals(scheme)) {
                            try {
                                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                                return true;
                            } catch (Exception ignored) {
                                return false;
                            }
                        }
                        return false;
                    }
                });

        getOnBackPressedDispatcher()
                .addCallback(
                        this,
                        new OnBackPressedCallback(true) {
                            @Override
                            public void handleOnBackPressed() {
                                if (webView.canGoBack()) {
                                    webView.goBack();
                                } else {
                                    setEnabled(false);
                                    getOnBackPressedDispatcher().onBackPressed();
                                }
                            }
                        });

        webView.loadUrl(START_URL);
    }

    private WebResourceResponse nativeFetch(WebResourceRequest request) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(request.getUrl().toString());
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            conn.setRequestMethod(request.getMethod());
            Map<String, String> reqHeaders = request.getRequestHeaders();
            if (reqHeaders != null) {
                for (Map.Entry<String, String> entry : reqHeaders.entrySet()) {
                    String key = entry.getKey();
                    if (key == null) continue;
                    String lower = key.toLowerCase(Locale.US);
                    if ("host".equals(lower) || "user-agent".equals(lower)) continue;
                    conn.setRequestProperty(key, entry.getValue());
                }
            }
            conn.setRequestProperty("Accept", "application/json");

            if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
                Map<String, String> headers = corsHeaders();
                return new WebResourceResponse(
                        "text/plain",
                        "UTF-8",
                        204,
                        "No Content",
                        headers,
                        new ByteArrayInputStream(new byte[0]));
            }

            int code = conn.getResponseCode();
            InputStream raw =
                    code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            byte[] body = raw == null ? new byte[0] : readAll(raw);
            String contentType = conn.getContentType();
            String mime = "application/json";
            String encoding = "UTF-8";
            if (contentType != null) {
                String[] parts = contentType.split(";");
                if (parts.length > 0 && parts[0].trim().length() > 0) {
                    mime = parts[0].trim();
                }
                for (String part : parts) {
                    String trimmed = part.trim();
                    if (trimmed.toLowerCase(Locale.US).startsWith("charset=")) {
                        encoding = trimmed.substring("charset=".length()).trim();
                    }
                }
            }
            String message = conn.getResponseMessage();
            if (message == null || message.trim().isEmpty()) {
                message = code >= 400 ? "Error" : "OK";
            }
            Map<String, String> headers = corsHeaders();
            Map<String, List<String>> rawHeaders = conn.getHeaderFields();
            if (rawHeaders != null) {
                List<String> cache = rawHeaders.get("Cache-Control");
                if (cache != null && !cache.isEmpty()) {
                    headers.put("Cache-Control", cache.get(0));
                }
            }
            return new WebResourceResponse(
                    mime, encoding, code, message, headers, new ByteArrayInputStream(body));
        } catch (Exception error) {
            String json = "{\"error\":{\"message\":\"lookup_failed\"}}";
            return new WebResourceResponse(
                    "application/json",
                    "UTF-8",
                    500,
                    "Error",
                    corsHeaders(),
                    new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8)));
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    private static Map<String, String> corsHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Access-Control-Allow-Methods", "GET, OPTIONS");
        headers.put("Access-Control-Allow-Headers", "*");
        return headers;
    }

    private static byte[] readAll(InputStream stream) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int n;
        while ((n = stream.read(buffer)) != -1) {
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }
}
