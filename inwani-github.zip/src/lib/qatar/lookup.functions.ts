import { createServerFn } from "@tanstack/react-start";
import {
  lookupQatarAddressCore,
  validateAddressQuery,
  type LookupResult,
} from "./lookup-core";

export type { LookupResult } from "./lookup-core";

export const lookupQatarAddress = createServerFn({ method: "GET" })
  .validator((raw: unknown) => validateAddressQuery(raw))
  .handler(async ({ data }): Promise<LookupResult> => lookupQatarAddressCore(data));
