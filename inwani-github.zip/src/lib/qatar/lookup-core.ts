import { getZone, MUNICIPALITIES } from "./zones";
import {
  formattedAddress,
  googleNavUrl,
  googleSearchUrl,
  wazeUrl,
  type AddressQuery,
  type Precision,
} from "./format";

export type LookupResult = {
  zone: number;
  street: number;
  building: number;
  lat: number | null;
  lng: number | null;
  precision: Precision;
  matchedBuilding: number | null;
  qars: string | null;
  pin: number | null;
  districtEn: string;
  districtAr: string;
  municipalityEn: string;
  municipalityAr: string;
  municipalityFa: string;
  formattedEn: string;
  formattedAr: string;
  googleSearchUrl: string;
  googleNavUrl: string | null;
  wazeUrl: string;
  error: "none" | "not_found" | "lookup_failed";
};

export type { AddressQuery };

type QarsFeature = {
  attributes?: {
    zone_no?: number;
    street_no?: number;
    building_no?: number;
    qars?: string;
    pin?: number;
  };
  geometry?: { x?: number; y?: number };
};

type QarsResponse = {
  features?: QarsFeature[];
  extent?: { xmin?: number; ymin?: number; xmax?: number; ymax?: number };
  error?: { message?: string };
};

const QARS_URL =
  "https://khazna.gisqatar.org.qa/host/rest/services/Hosted/Qatar_Address_Reference_System/FeatureServer/0/query";

export function validateAddressQuery(raw: unknown): AddressQuery {
  const data = (raw ?? {}) as Record<string, unknown>;
  const zone = Number(data.zone);
  const street = Number(data.street);
  const building = Number(data.building);
  if (!Number.isInteger(zone) || zone < 1 || zone > 99) {
    throw new Error("Invalid zone");
  }
  if (!Number.isInteger(street) || street < 1 || street > 9999) {
    throw new Error("Invalid street");
  }
  if (!Number.isInteger(building) || building < 1 || building > 9999) {
    throw new Error("Invalid building");
  }
  return { zone, street, building };
}

function emptyResult(q: AddressQuery, error: LookupResult["error"]): LookupResult {
  const zone = getZone(q.zone);
  const muni = zone ? MUNICIPALITIES[zone.m] : undefined;
  const formattedEn = formattedAddress(q, "en");
  const formattedAr = formattedAddress(q, "ar");
  return {
    zone: q.zone,
    street: q.street,
    building: q.building,
    lat: null,
    lng: null,
    precision: "none",
    matchedBuilding: null,
    qars: null,
    pin: null,
    districtEn: zone?.en ?? `Zone ${q.zone}`,
    districtAr: zone?.ar ?? String(q.zone),
    municipalityEn: muni?.en ?? "Qatar",
    municipalityAr: muni?.ar ?? "قطر",
    municipalityFa: muni?.fa ?? "قطر",
    formattedEn,
    formattedAr,
    googleSearchUrl: googleSearchUrl(formattedEn),
    googleNavUrl: null,
    wazeUrl: wazeUrl(null, null, formattedEn),
    error,
  };
}

function withPoint(
  base: LookupResult,
  lat: number,
  lng: number,
  extra: Partial<LookupResult>,
): LookupResult {
  return {
    ...base,
    ...extra,
    lat,
    lng,
    googleSearchUrl: googleSearchUrl(base.formattedEn, lat, lng),
    googleNavUrl: googleNavUrl(lat, lng),
    wazeUrl: wazeUrl(lat, lng, base.formattedEn),
    error: "none",
  };
}

async function qarsQuery(params: Record<string, string>): Promise<QarsResponse> {
  const url = new URL(QARS_URL);
  for (const [key, value] of Object.entries(params)) {
    url.searchParams.set(key, value);
  }
  url.searchParams.set("f", "json");
  url.searchParams.set("outSR", "4326");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const res = await fetch(url, {
      headers: { Accept: "application/json" },
      signal: controller.signal,
    });
    if (!res.ok) {
      throw new Error(`QARS ${res.status}`);
    }
    return (await res.json()) as QarsResponse;
  } finally {
    clearTimeout(timer);
  }
}

function readPoint(feature: QarsFeature | undefined): { lat: number; lng: number } | null {
  const lat = feature?.geometry?.y;
  const lng = feature?.geometry?.x;
  if (typeof lat !== "number" || typeof lng !== "number") return null;
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  return { lat, lng };
}

export async function lookupQatarAddressCore(data: AddressQuery): Promise<LookupResult> {
  const base = emptyResult(data, "not_found");
  try {
    const exact = await qarsQuery({
      where: `zone_no=${data.zone} AND street_no=${data.street} AND building_no=${data.building}`,
      outFields: "zone_no,street_no,building_no,qars,pin",
      returnGeometry: "true",
      resultRecordCount: "1",
    });
    const exactPoint = readPoint(exact.features?.[0]);
    if (exactPoint) {
      const attrs = exact.features?.[0]?.attributes;
      return withPoint(base, exactPoint.lat, exactPoint.lng, {
        precision: "building",
        matchedBuilding: data.building,
        qars: attrs?.qars ?? null,
        pin: attrs?.pin ?? null,
      });
    }

    const streetHits = await qarsQuery({
      where: `zone_no=${data.zone} AND street_no=${data.street}`,
      outFields: "zone_no,street_no,building_no,qars,pin",
      returnGeometry: "true",
      resultRecordCount: "200",
      orderByFields: "building_no",
    });
    const streetFeatures = streetHits.features ?? [];
    if (streetFeatures.length > 0) {
      let best = streetFeatures[0];
      let bestDelta = Number.POSITIVE_INFINITY;
      for (const feature of streetFeatures) {
        const n = feature.attributes?.building_no;
        if (typeof n !== "number") continue;
        const delta = Math.abs(n - data.building);
        if (delta < bestDelta) {
          best = feature;
          bestDelta = delta;
        }
      }
      const point = readPoint(best);
      if (point) {
        return withPoint(base, point.lat, point.lng, {
          precision: "nearest",
          matchedBuilding: best.attributes?.building_no ?? null,
          qars: best.attributes?.qars ?? null,
          pin: best.attributes?.pin ?? null,
        });
      }
    }

    const extentRes = await qarsQuery({
      where: `zone_no=${data.zone}`,
      returnExtentOnly: "true",
    });
    const ext = extentRes.extent;
    if (
      ext &&
      typeof ext.xmin === "number" &&
      typeof ext.xmax === "number" &&
      typeof ext.ymin === "number" &&
      typeof ext.ymax === "number"
    ) {
      const lat = (ext.ymin + ext.ymax) / 2;
      const lng = (ext.xmin + ext.xmax) / 2;
      return withPoint(base, lat, lng, { precision: "zone" });
    }

    return base;
  } catch {
    return emptyResult(data, "lookup_failed");
  }
}
