import {
  lookupQatarAddressCore,
  validateAddressQuery,
  type LookupResult,
} from "@/lib/qatar/lookup-core";

export type { LookupResult };

export async function lookupQatarAddress(opts: { data: unknown }): Promise<LookupResult> {
  return lookupQatarAddressCore(validateAddressQuery(opts.data));
}
