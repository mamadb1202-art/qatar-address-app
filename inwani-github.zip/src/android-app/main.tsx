import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import {
  Outlet,
  RouterProvider,
  createHashHistory,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import { Toaster } from "sonner";
import { AddressApp } from "@/components/address-app";
import type { AddressSearch } from "@/lib/qatar/format";
import "@/styles.css";

function optionalInt(value: unknown): number | undefined {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1) return undefined;
  return n;
}

const rootRoute = createRootRoute({
  component: () => (
    <>
      <Outlet />
      <Toaster
        position="top-center"
        toastOptions={{
          className: "font-sans text-sm",
        }}
      />
    </>
  ),
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  validateSearch: (raw: Record<string, unknown>): AddressSearch => ({
    z: optionalInt(raw.z),
    s: optionalInt(raw.s),
    b: optionalInt(raw.b),
  }),
  component: function Home() {
    const search = indexRoute.useSearch();
    return <AddressApp initial={search} />;
  },
});

const router = createRouter({
  routeTree: rootRoute.addChildren([indexRoute]),
  history: createHashHistory(),
});

const el = document.getElementById("root");
if (!el) {
  throw new Error("Root element missing");
}

createRoot(el).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
);
