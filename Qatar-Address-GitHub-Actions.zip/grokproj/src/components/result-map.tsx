import { useEffect, useRef, useState } from "react";
import "leaflet/dist/leaflet.css";
import { cn } from "@/lib/utils";
import type { Locale } from "@/lib/qatar/i18n";
import { STRINGS } from "@/lib/qatar/i18n";

type ResultMapProps = {
  lat: number;
  lng: number;
  label: string;
  locale: Locale;
};

export function ResultMap({ lat, lng, label, locale }: ResultMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<import("leaflet").Map | null>(null);
  const layersRef = useRef<{
    streets?: import("leaflet").TileLayer;
    satellite?: import("leaflet").TileLayer;
    marker?: import("leaflet").Layer;
  }>({});
  const [satellite, setSatellite] = useState(true);
  const t = STRINGS[locale];

  useEffect(() => {
    let cancelled = false;
    const el = containerRef.current;
    if (!el) return;

    void (async () => {
      const leaflet = await import("leaflet");
      const L = leaflet.default ?? leaflet;
      if (cancelled || !containerRef.current) return;

      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }

      const map = L.map(containerRef.current, {
        zoomControl: false,
        attributionControl: true,
      }).setView([lat, lng], 18);

      const streets = L.tileLayer(
        "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
        {
          attribution: "&copy; OpenStreetMap &copy; CARTO",
          maxZoom: 20,
          subdomains: "abcd",
        },
      );
      const imagery = L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        {
          attribution: "Tiles &copy; Esri",
          maxZoom: 19,
        },
      );

      imagery.addTo(map);
      L.control.zoom({ position: "topright" }).addTo(map);

      const icon = L.divIcon({
        className: "inwani-marker",
        html: `<span class="inwani-marker-dot" title="${label}"></span>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });
      const marker = L.marker([lat, lng], { icon, title: label }).addTo(map);

      mapRef.current = map;
      layersRef.current = { streets, satellite: imagery, marker };
      requestAnimationFrame(() => map.invalidateSize());
      window.setTimeout(() => map.invalidateSize(), 250);
    })();

    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, [lat, lng, label]);

  useEffect(() => {
    const map = mapRef.current;
    const { streets, satellite: imagery } = layersRef.current;
    if (!map || !streets || !imagery) return;
    if (satellite) {
      if (map.hasLayer(streets)) map.removeLayer(streets);
      if (!map.hasLayer(imagery)) imagery.addTo(map);
    } else {
      if (map.hasLayer(imagery)) map.removeLayer(imagery);
      if (!map.hasLayer(streets)) streets.addTo(map);
    }
  }, [satellite]);

  return (
    <div className="relative overflow-hidden rounded-xl bg-surface-muted">
      <div ref={containerRef} className="h-72 w-full md:h-96" />
      <div className="absolute start-3 top-3 z-10 flex gap-1 rounded-lg bg-surface/92 p-1 shadow-border">
        <button
          type="button"
          onClick={() => setSatellite(true)}
          className={cn(
            "h-9 rounded-md px-3 text-xs font-medium",
            satellite ? "bg-primary text-primary-fg" : "text-muted hover:text-fg",
          )}
        >
          {t.satellite}
        </button>
        <button
          type="button"
          onClick={() => setSatellite(false)}
          className={cn(
            "h-9 rounded-md px-3 text-xs font-medium",
            !satellite ? "bg-primary text-primary-fg" : "text-muted hover:text-fg",
          )}
        >
          {t.mapView}
        </button>
      </div>
    </div>
  );
}
