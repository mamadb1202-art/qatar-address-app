import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import {
  Copy,
  LoaderCircle,
  MapPinned,
  Navigation,
  Search,
  Share2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ResultMap } from "@/components/result-map";
import { cn } from "@/lib/utils";
import { LOCALES, STRINGS, localeDir, localeLang, type Locale } from "@/lib/qatar/i18n";
import { formatCoords, parsePlateNumber, type AddressSearch } from "@/lib/qatar/format";
import {
  lookupQatarAddress,
  lookupQatarAddressMobile,
  type LookupResult,
} from "@/lib/qatar/lookup.functions";
import { getZone, MUNICIPALITIES, searchZones, type Zone } from "@/lib/qatar/zones";

const LOCALE_KEY = "inwani-locale";
const RECENT_KEY = "inwani-recent-v1";
const SAMPLE = { zone: 38, street: 343, building: 12 };

type RecentItem = {
  zone: number;
  street: number;
  building: number;
  label: string;
};

function readLocale(): Locale {
  if (typeof window === "undefined") return "fa";
  const stored = window.localStorage.getItem(LOCALE_KEY);
  if (stored === "fa" || stored === "ar" || stored === "en") return stored;
  const langs = window.navigator.languages ?? [window.navigator.language];
  if (langs.some((l) => l.toLowerCase().startsWith("fa"))) return "fa";
  if (langs.some((l) => l.toLowerCase().startsWith("ar"))) return "ar";
  return "fa";
}

function readRecent(): RecentItem[] {
  try {
    const raw = localStorage.getItem(RECENT_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as RecentItem[];
    return Array.isArray(parsed) ? parsed.slice(0, 8) : [];
  } catch {
    return [];
  }
}

function saveRecent(item: RecentItem) {
  const next = [
    item,
    ...readRecent().filter(
      (r) =>
        !(r.zone === item.zone && r.street === item.street && r.building === item.building),
    ),
  ].slice(0, 8);
  localStorage.setItem(RECENT_KEY, JSON.stringify(next));
  return next;
}

function districtLabel(zone: Zone | undefined, locale: Locale) {
  if (!zone) return "";
  const muni = MUNICIPALITIES[zone.m];
  if (locale === "en") return `${zone.en} · ${muni.en}`;
  if (locale === "fa") return `${zone.ar} · ${muni.fa}`;
  return `${zone.ar} · ${muni.ar}`;
}

function precisionMessage(result: LookupResult, locale: Locale) {
  const t = STRINGS[locale];
  if (result.error === "lookup_failed") return t.lookupFailed;
  if (result.precision === "building") return t.exact;
  if (result.precision === "nearest") {
    return result.matchedBuilding
      ? `${t.nearest} (${result.matchedBuilding})`
      : t.nearest;
  }
  if (result.precision === "street") return t.streetLevel;
  if (result.precision === "zone") return t.zoneLevel;
  return t.notFound;
}

export function AddressApp({ initial }: { initial: AddressSearch }) {
  const navigate = useNavigate({ from: "/" });
  const [locale, setLocale] = useState<Locale>("fa");
  const [zone, setZone] = useState<number | "">(initial.z ?? "");
  const [street, setStreet] = useState<number | "">(initial.s ?? "");
  const [building, setBuilding] = useState<number | "">(initial.b ?? "");
  const [districtQuery, setDistrictQuery] = useState("");
  const [result, setResult] = useState<LookupResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [recent, setRecent] = useState<RecentItem[]>([]);
  const didAuto = useRef(false);
  const t = STRINGS[locale];
  const dir = localeDir(locale);

  useEffect(() => {
    setLocale(readLocale());
    setRecent(readRecent());
  }, []);

  useEffect(() => {
    document.documentElement.lang = localeLang(locale);
    document.documentElement.dir = dir;
    localStorage.setItem(LOCALE_KEY, locale);
  }, [locale, dir]);

  const zoneMeta = typeof zone === "number" ? getZone(zone) : undefined;
  const districtMatches = useMemo(
    () => (districtQuery.trim().length >= 2 ? searchZones(districtQuery) : []),
    [districtQuery],
  );

  async function runLookup(q: { zone: number; street: number; building: number }) {
    setLoading(true);
    try {
      const found = import.meta.env.VITE_CAPACITOR === "true"
        ? await lookupQatarAddressMobile(q)
        : await lookupQatarAddress({ data: q });
      setResult(found);
      const zoneInfo = getZone(q.zone);
      setRecent(
        saveRecent({
          ...q,
          label: zoneInfo
            ? locale === "en"
              ? zoneInfo.en
              : zoneInfo.ar
            : `Zone ${q.zone}`,
        }),
      );
      await navigate({
        search: { z: q.zone, s: q.street, b: q.building },
        replace: true,
      });
    } catch {
      toast.error(STRINGS[locale].lookupFailed);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (didAuto.current) return;
    if (initial.z && initial.s && initial.b) {
      didAuto.current = true;
      void runLookup({ zone: initial.z, street: initial.s, building: initial.b });
    }
    // First paint only — lookup uses the numbers from the shared link.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (zone === "" || street === "" || building === "") {
      toast.error(t.required);
      return;
    }
    void runLookup({ zone, street, building });
  }

  function fill(q: { zone: number; street: number; building: number }) {
    setZone(q.zone);
    setStreet(q.street);
    setBuilding(q.building);
    void runLookup(q);
  }

  async function copyText(value: string) {
    try {
      await navigator.clipboard.writeText(value);
      toast.success(t.copied);
    } catch {
      toast.error(t.copied);
    }
  }

  async function shareResult(found: LookupResult) {
    const text = [
      locale === "en" ? found.formattedEn : found.formattedAr,
      found.lat != null && found.lng != null ? formatCoords(found.lat, found.lng) : "",
      found.googleSearchUrl,
      found.wazeUrl,
    ]
      .filter(Boolean)
      .join("\n");
    if (navigator.share) {
      try {
        await navigator.share({ title: t.appName, text });
        return;
      } catch {
        /* fall through to copy */
      }
    }
    await copyText(text);
  }

  const shareLinks =
    result != null ? `${result.googleSearchUrl}\n${result.wazeUrl}` : "";

  return (
    <div className="min-h-dvh bg-bg text-fg" dir={dir}>
      <div className="mx-auto flex w-full max-w-lg flex-col gap-6 px-4 py-6 pb-16 md:max-w-2xl md:py-10">
        <header className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium tracking-wide text-muted">Inwani · إنواني</p>
            <h1 className="mt-1 text-3xl font-semibold tracking-tight text-fg md:text-4xl">
              {t.appName}
            </h1>
            <p className="mt-2 max-w-md text-sm leading-relaxed text-muted">{t.tagline}</p>
          </div>
          <div className="flex shrink-0 rounded-lg bg-surface p-1 shadow-border">
            {LOCALES.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setLocale(item.id)}
                className={cn(
                  "h-9 min-w-9 rounded-md px-2.5 text-xs font-medium",
                  locale === item.id ? "bg-primary text-primary-fg" : "text-muted hover:text-fg",
                )}
              >
                {item.label}
              </button>
            ))}
          </div>
        </header>

        <form onSubmit={onSubmit} className="flex flex-col gap-4">
          <div className="rounded-3xl bg-plate p-3 text-plate-fg shadow-plate">
            <div className="flex items-center justify-between px-2 pt-1 text-xs font-medium uppercase tracking-wide text-plate-muted">
              <span>State of Qatar</span>
              <span>دولة قطر</span>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2">
              <PlateField
                label={t.zone}
                hint="Zone"
                value={zone}
                onChange={setZone}
                autoFocus
              />
              <PlateField
                label={t.street}
                hint="Street"
                value={street}
                onChange={setStreet}
              />
              <PlateField
                label={t.building}
                hint="Building"
                value={building}
                onChange={setBuilding}
              />
            </div>
            <p className="mt-3 px-2 pb-1 text-center text-xs text-plate-muted">{t.plateHint}</p>
          </div>

          {zoneMeta ? (
            <p className="text-sm text-muted">
              <span className="font-medium text-fg">{t.district}: </span>
              {districtLabel(zoneMeta, locale)}
            </p>
          ) : null}

          <label className="flex flex-col gap-2">
            <span className="text-xs font-medium text-muted">{t.searchDistrict}</span>
            <div className="relative">
              <Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-subtle" />
              <Input
                value={districtQuery}
                onChange={(e) => setDistrictQuery(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="ps-10"
                autoComplete="off"
              />
            </div>
            {districtMatches.length > 0 ? (
              <ul className="overflow-hidden rounded-xl bg-surface shadow-border">
                {districtMatches.map((item) => (
                  <li key={item.n}>
                    <button
                      type="button"
                      onClick={() => {
                        setZone(item.n);
                        setDistrictQuery("");
                      }}
                      className="flex w-full items-center justify-between gap-3 px-3 py-3 text-start hover:bg-surface-muted"
                    >
                      <span className="min-w-0 truncate text-sm">
                        {locale === "en" ? item.en : item.ar}
                      </span>
                      <span className="shrink-0 text-xs tabular-nums text-muted">
                        {t.zone} {item.n}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            ) : null}
          </label>

          <Button type="submit" size="lg" disabled={loading} className="w-full">
            {loading ? <LoaderCircle className="animate-spin" /> : <MapPinned />}
            {loading ? t.finding : t.find}
          </Button>

          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="soft" size="sm" onClick={() => fill(SAMPLE)}>
              {t.trySample}
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => {
                setZone("");
                setStreet("");
                setBuilding("");
                setResult(null);
                void navigate({ search: {}, replace: true });
              }}
            >
              {t.clear}
            </Button>
          </div>
        </form>

        {result ? (
          <section className="flex flex-col gap-4 rounded-3xl bg-surface p-3 shadow-border md:p-4">
            <div className="px-1 pt-1">
              <p
                className={cn(
                  "text-xs font-medium",
                  result.precision === "building"
                    ? "text-ok"
                    : result.precision === "none"
                      ? "text-danger"
                      : "text-warn",
                )}
              >
                {precisionMessage(result, locale)}
              </p>
              <h2 className="mt-1 text-lg font-semibold leading-snug">
                {locale === "en" ? result.formattedEn : result.formattedAr}
              </h2>
              <p className="mt-1 text-sm text-muted">
                {locale === "en" ? result.formattedAr : result.formattedEn}
              </p>
            </div>

            {result.lat != null && result.lng != null ? (
              <ResultMap
                lat={result.lat}
                lng={result.lng}
                label={result.formattedEn}
                locale={locale}
              />
            ) : (
              <div className="flex h-40 items-center justify-center rounded-xl bg-surface-muted px-6 text-center text-sm text-muted">
                {t.openMaps}
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              <a
                href={result.googleSearchUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex h-12 min-h-12 items-center justify-center gap-2 rounded-lg bg-primary px-3 text-sm font-medium text-primary-fg"
              >
                <MapPinned className="size-4" />
                {t.google}
              </a>
              <a
                href={result.wazeUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex h-12 min-h-12 items-center justify-center gap-2 rounded-lg bg-surface text-sm font-medium text-fg shadow-border"
              >
                <Navigation className="size-4" />
                {t.waze}
              </a>
              {result.googleNavUrl ? (
                <a
                  href={result.googleNavUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex h-11 min-h-11 items-center justify-center gap-2 rounded-lg bg-primary/8 px-3 text-sm font-medium text-primary"
                >
                  {t.navigateGoogle}
                </a>
              ) : null}
              <a
                href={result.wazeUrl}
                target="_blank"
                rel="noreferrer"
                className="col-span-2 inline-flex h-11 min-h-11 items-center justify-center gap-2 rounded-lg bg-primary/8 px-3 text-sm font-medium text-primary sm:col-span-1"
              >
                {t.navigateWaze}
              </a>
            </div>

            <dl className="grid grid-cols-1 gap-3 px-1 text-sm md:grid-cols-2">
              {result.lat != null && result.lng != null ? (
                <div>
                  <dt className="text-xs text-muted">{t.coords}</dt>
                  <dd className="mt-0.5 font-medium tabular-nums">
                    {formatCoords(result.lat, result.lng)}
                  </dd>
                </div>
              ) : null}
              {result.qars ? (
                <div>
                  <dt className="text-xs text-muted">{t.qars}</dt>
                  <dd className="mt-0.5 font-medium tabular-nums">{result.qars}</dd>
                </div>
              ) : null}
            </dl>

            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() =>
                  copyText(locale === "en" ? result.formattedEn : result.formattedAr)
                }
              >
                <Copy />
                {t.copyAddress}
              </Button>
              {result.lat != null && result.lng != null ? (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => copyText(formatCoords(result.lat!, result.lng!))}
                >
                  <Copy />
                  {t.copyCoords}
                </Button>
              ) : null}
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => copyText(shareLinks)}
              >
                <Copy />
                {t.copyLinks}
              </Button>
              <Button type="button" variant="outline" size="sm" onClick={() => void shareResult(result)}>
                <Share2 />
                {t.share}
              </Button>
            </div>
          </section>
        ) : null}

        <section className="flex flex-col gap-3">
          <h2 className="text-sm font-medium text-muted">{t.recent}</h2>
          {recent.length === 0 ? (
            <p className="text-sm text-subtle">{t.noRecent}</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {recent.map((item) => (
                <li key={`${item.zone}-${item.street}-${item.building}`}>
                  <button
                    type="button"
                    onClick={() => fill(item)}
                    className="flex w-full items-center justify-between gap-3 rounded-xl bg-surface px-4 py-3 text-start shadow-border hover:shadow-border-hover"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium">{item.label}</span>
                      <span className="mt-0.5 block text-xs tabular-nums text-muted">
                        {t.zone} {item.zone} · {t.street} {item.street} · {t.building}{" "}
                        {item.building}
                      </span>
                    </span>
                    <MapPinned className="size-4 shrink-0 text-subtle" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}

function PlateField({
  label,
  hint,
  value,
  onChange,
  autoFocus,
}: {
  label: string;
  hint: string;
  value: number | "";
  onChange: (value: number | "") => void;
  autoFocus?: boolean;
}) {
  return (
    <label className="flex flex-col gap-1.5 rounded-xl bg-plate-fg/10 px-2 py-2">
      <span className="text-center text-xs font-medium text-plate-muted">{label}</span>
      <input
        inputMode="numeric"
        pattern="[0-9]*"
        autoFocus={autoFocus}
        value={value}
        onChange={(e) => onChange(parsePlateNumber(e.target.value))}
        className="h-14 w-full bg-transparent text-center text-3xl font-semibold tabular-nums text-plate-fg outline-none md:text-4xl"
        aria-label={label}
      />
      <span className="text-center text-xs uppercase tracking-wide text-plate-muted">
        {hint}
      </span>
    </label>
  );
}
