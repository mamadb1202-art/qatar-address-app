import { getZone, MUNICIPALITIES } from "./zones";
import type { Locale } from "./i18n";

export type Precision = "building" | "nearest" | "street" | "zone" | "none";

export type AddressQuery = {
  zone: number;
  street: number;
  building: number;
};

export type AddressSearch = {
  z?: number;
  s?: number;
  b?: number;
};

export function formattedAddress(q: AddressQuery, locale: Locale): string {
  const zone = getZone(q.zone);
  const muni = zone ? MUNICIPALITIES[zone.m] : undefined;
  if (locale === "en") {
    const district = zone?.en ?? `Zone ${q.zone}`;
    const city = muni?.en ?? "Qatar";
    return `Building ${q.building}, Street ${q.street}, Zone ${q.zone}, ${district}, ${city}, Qatar`;
  }
  const district = zone?.ar ?? String(q.zone);
  const city = muni?.ar ?? "قطر";
  return `مبنى ${q.building}، شارع ${q.street}، منطقة ${q.zone}، ${district}، ${city}، قطر`;
}

export function googleSearchUrl(query: string, lat?: number | null, lng?: number | null) {
  if (lat != null && lng != null) {
    return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
  }
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}

export function googleNavUrl(lat: number, lng: number) {
  return `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=driving`;
}

export function wazeUrl(lat?: number | null, lng?: number | null, query?: string) {
  if (lat != null && lng != null) {
    return `https://waze.com/ul?ll=${lat},${lng}&navigate=yes&zoom=17`;
  }
  return `https://waze.com/ul?q=${encodeURIComponent(query ?? "")}&navigate=yes`;
}

export function formatCoords(lat: number, lng: number) {
  return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
}

export function parsePlateNumber(raw: string): number | "" {
  const digits = raw.replace(/[^\d]/g, "");
  if (!digits) return "";
  const n = Number(digits);
  if (!Number.isFinite(n) || n < 0) return "";
  return n;
}
