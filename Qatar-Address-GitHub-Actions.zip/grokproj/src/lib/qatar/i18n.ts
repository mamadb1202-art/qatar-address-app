export type Locale = "fa" | "ar" | "en";

export const LOCALES: { id: Locale; label: string }[] = [
  { id: "fa", label: "فا" },
  { id: "ar", label: "ع" },
  { id: "en", label: "EN" },
];

export const STRINGS: Record<
  Locale,
  {
    appName: string;
    tagline: string;
    zone: string;
    street: string;
    building: string;
    find: string;
    finding: string;
    google: string;
    waze: string;
    navigateGoogle: string;
    navigateWaze: string;
    copyAddress: string;
    copyCoords: string;
    copyLinks: string;
    share: string;
    recent: string;
    searchDistrict: string;
    searchPlaceholder: string;
    notFound: string;
    nearest: string;
    streetLevel: string;
    zoneLevel: string;
    exact: string;
    copied: string;
    example: string;
    coords: string;
    address: string;
    satellite: string;
    mapView: string;
    plateHint: string;
    openMaps: string;
    noRecent: string;
    lookupFailed: string;
    required: string;
    pin: string;
    qars: string;
    trySample: string;
    clear: string;
    district: string;
  }
> = {
  fa: {
    appName: "آدرس قطر",
    tagline: "شماره پلاک آبی را بزن؛ موقعیت، گوگل مپ و ویز را بگیر",
    zone: "منطقه",
    street: "خیابان",
    building: "ساختمان",
    find: "پیدا کردن موقعیت",
    finding: "در حال جستجو…",
    google: "گوگل مپ",
    waze: "ویز",
    navigateGoogle: "مسیر با گوگل مپ",
    navigateWaze: "مسیر با ویز",
    copyAddress: "کپی آدرس",
    copyCoords: "کپی مختصات",
    copyLinks: "کپی لینک‌ها",
    share: "اشتراک",
    recent: "جستجوهای اخیر",
    searchDistrict: "جستجوی محله",
    searchPlaceholder: "مثلاً السد، الوعب، لوسیل",
    notFound: "این پلاک در سامانه آدرس قطر پیدا نشد. لینک جستجوی گوگل مپ و ویز ساخته شد.",
    nearest: "ساختمان دقیق نبود؛ نزدیک‌ترین پلاک همین خیابان نشان داده شد.",
    streetLevel: "موقعیت تقریبی خیابان",
    zoneLevel: "موقعیت تقریبی منطقه",
    exact: "موقعیت دقیق ساختمان",
    copied: "کپی شد",
    example: "نمونه",
    coords: "مختصات",
    address: "آدرس",
    satellite: "ماهواره",
    mapView: "نقشه",
    plateHint: "همان اعداد روی پلاک آبی إنواني",
    openMaps: "باز کردن نقشه",
    noRecent: "هنوز جستجویی نشده",
    lookupFailed: "اتصال به سامانه آدرس قطر برقرار نشد. لینک‌های جستجو آماده است.",
    required: "هر سه شماره لازم است",
    pin: "پین",
    qars: "کد آدرس",
    trySample: "امتحان با نمونه السد",
    clear: "پاک کردن",
    district: "محله",
  },
  ar: {
    appName: "عنوان قطر",
    tagline: "أدخل أرقام اللوحة الزرقاء لتحصل على الموقع وخرائط جوجل وويز",
    zone: "المنطقة",
    street: "الشارع",
    building: "المبنى",
    find: "إيجاد الموقع",
    finding: "جاري البحث…",
    google: "خرائط جوجل",
    waze: "ويز",
    navigateGoogle: "التوجيه عبر جوجل",
    navigateWaze: "التوجيه عبر ويز",
    copyAddress: "نسخ العنوان",
    copyCoords: "نسخ الإحداثيات",
    copyLinks: "نسخ الروابط",
    share: "مشاركة",
    recent: "عمليات البحث الأخيرة",
    searchDistrict: "البحث عن الحي",
    searchPlaceholder: "مثلاً السد، الوعب، لوسيل",
    notFound: "لم يُعثر على هذا الرقم في نظام العنوان الوطني. تم إنشاء روابط البحث.",
    nearest: "المبنى غير مطابق؛ أقرب مبنى في الشارع نفسه.",
    streetLevel: "موقع تقريبي للشارع",
    zoneLevel: "موقع تقريبي للمنطقة",
    exact: "موقع المبنى بدقة",
    copied: "تم النسخ",
    example: "مثال",
    coords: "الإحداثيات",
    address: "العنوان",
    satellite: "قمر صناعي",
    mapView: "خريطة",
    plateHint: "الأرقام نفسها على لوحة إنواني الزرقاء",
    openMaps: "فتح الخريطة",
    noRecent: "لا توجد عمليات بحث بعد",
    lookupFailed: "تعذر الاتصال بنظام العنوان. روابط البحث جاهزة.",
    required: "الأرقام الثلاثة مطلوبة",
    pin: "الرمز",
    qars: "رمز العنوان",
    trySample: "تجربة مثال السد",
    clear: "مسح",
    district: "الحي",
  },
  en: {
    appName: "Qatar Address",
    tagline: "Enter the blue plate numbers to get the pin, Google Maps, and Waze",
    zone: "Zone",
    street: "Street",
    building: "Building",
    find: "Find location",
    finding: "Searching…",
    google: "Google Maps",
    waze: "Waze",
    navigateGoogle: "Navigate with Google",
    navigateWaze: "Navigate with Waze",
    copyAddress: "Copy address",
    copyCoords: "Copy coordinates",
    copyLinks: "Copy links",
    share: "Share",
    recent: "Recent searches",
    searchDistrict: "Search district",
    searchPlaceholder: "e.g. Al Sadd, Al Waab, Lusail",
    notFound: "This plate was not in the national address system. Search links are ready.",
    nearest: "Exact building missing; showing the closest building on this street.",
    streetLevel: "Approximate street location",
    zoneLevel: "Approximate zone location",
    exact: "Exact building location",
    copied: "Copied",
    example: "Sample",
    coords: "Coordinates",
    address: "Address",
    satellite: "Satellite",
    mapView: "Map",
    plateHint: "The numbers on the blue Inwani plate",
    openMaps: "Open map",
    noRecent: "No searches yet",
    lookupFailed: "Could not reach the address service. Search links are ready.",
    required: "All three numbers are required",
    pin: "PIN",
    qars: "Address code",
    trySample: "Try Al Sadd sample",
    clear: "Clear",
    district: "District",
  },
};

export function localeDir(locale: Locale): "rtl" | "ltr" {
  return locale === "en" ? "ltr" : "rtl";
}

export function localeLang(locale: Locale): string {
  return locale;
}
