import { createFileRoute } from "@tanstack/react-router";
import { AddressApp } from "@/components/address-app";
import type { AddressSearch } from "@/lib/qatar/format";

function optionalInt(value: unknown): number | undefined {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1) return undefined;
  return n;
}

export const Route = createFileRoute("/")({
  validateSearch: (raw: Record<string, unknown>): AddressSearch => ({
    z: optionalInt(raw.z),
    s: optionalInt(raw.s),
    b: optionalInt(raw.b),
  }),
  component: Home,
});

function Home() {
  const search = Route.useSearch();
  return <AddressApp initial={search} />;
}
