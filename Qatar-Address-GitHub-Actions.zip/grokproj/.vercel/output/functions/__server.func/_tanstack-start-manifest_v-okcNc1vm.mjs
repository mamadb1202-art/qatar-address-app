//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-okcNc1vm.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-13jadcLx.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-13jadcLx.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		css: ["/assets/routes-vh-t_kPv.css"],
		preloads: ["/assets/routes-D5cQp0QQ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
