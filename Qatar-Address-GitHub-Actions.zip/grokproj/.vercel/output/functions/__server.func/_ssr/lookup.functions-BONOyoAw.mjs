import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as googleNavUrl, i as getZone, l as wazeUrl, o as googleSearchUrl, r as formattedAddress, t as MUNICIPALITIES } from "./format-DlqtK3md.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lookup.functions-BONOyoAw.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var QARS_URL = "https://khazna.gisqatar.org.qa/host/rest/services/Hosted/Qatar_Address_Reference_System/FeatureServer/0/query";
function emptyResult(q, error) {
	const zone = getZone(q.zone);
	const muni = zone ? MUNICIPALITIES[zone.m] : void 0;
	const formattedEn = formattedAddress(q, "en");
	const formattedAr = formattedAddress(q, "ar");
	return {
		zone: q.zone,
		street: q.street,
		building: q.building,
		lat: null,
		lng: null,
		precision: "none",
		matchedBuilding: null,
		qars: null,
		pin: null,
		districtEn: zone?.en ?? `Zone ${q.zone}`,
		districtAr: zone?.ar ?? String(q.zone),
		municipalityEn: muni?.en ?? "Qatar",
		municipalityAr: muni?.ar ?? "قطر",
		municipalityFa: muni?.fa ?? "قطر",
		formattedEn,
		formattedAr,
		googleSearchUrl: googleSearchUrl(formattedEn),
		googleNavUrl: null,
		wazeUrl: wazeUrl(null, null, formattedEn),
		error
	};
}
function withPoint(base, lat, lng, extra) {
	return {
		...base,
		...extra,
		lat,
		lng,
		googleSearchUrl: googleSearchUrl(base.formattedEn, lat, lng),
		googleNavUrl: googleNavUrl(lat, lng),
		wazeUrl: wazeUrl(lat, lng, base.formattedEn),
		error: "none"
	};
}
async function qarsQuery(params) {
	const url = new URL(QARS_URL);
	for (const [key, value] of Object.entries(params)) url.searchParams.set(key, value);
	url.searchParams.set("f", "json");
	url.searchParams.set("outSR", "4326");
	const res = await fetch(url, {
		headers: { Accept: "application/json" },
		signal: AbortSignal.timeout(12e3)
	});
	if (!res.ok) throw new Error(`QARS ${res.status}`);
	return await res.json();
}
function readPoint(feature) {
	const lat = feature?.geometry?.y;
	const lng = feature?.geometry?.x;
	if (typeof lat !== "number" || typeof lng !== "number") return null;
	if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
	return {
		lat,
		lng
	};
}
var lookupQatarAddress_createServerFn_handler = createServerRpc({
	id: "0378ddf04db7b73a7eb4c8c6c32be72c340306ac9b25067ee3c492c3ccbd58cf",
	name: "lookupQatarAddress",
	filename: "src/lib/qatar/lookup.functions.ts"
}, (opts) => lookupQatarAddress.__executeServer(opts));
var lookupQatarAddress = createServerFn({ method: "GET" }).validator((raw) => {
	const data = raw ?? {};
	const zone = Number(data.zone);
	const street = Number(data.street);
	const building = Number(data.building);
	if (!Number.isInteger(zone) || zone < 1 || zone > 99) throw new Error("Invalid zone");
	if (!Number.isInteger(street) || street < 1 || street > 9999) throw new Error("Invalid street");
	if (!Number.isInteger(building) || building < 1 || building > 9999) throw new Error("Invalid building");
	return {
		zone,
		street,
		building
	};
}).handler(lookupQatarAddress_createServerFn_handler, async ({ data }) => {
	const base = emptyResult(data, "not_found");
	try {
		const exact = await qarsQuery({
			where: `zone_no=${data.zone} AND street_no=${data.street} AND building_no=${data.building}`,
			outFields: "zone_no,street_no,building_no,qars,pin",
			returnGeometry: "true",
			resultRecordCount: "1"
		});
		const exactPoint = readPoint(exact.features?.[0]);
		if (exactPoint) {
			const attrs = exact.features?.[0]?.attributes;
			return withPoint(base, exactPoint.lat, exactPoint.lng, {
				precision: "building",
				matchedBuilding: data.building,
				qars: attrs?.qars ?? null,
				pin: attrs?.pin ?? null
			});
		}
		const streetFeatures = (await qarsQuery({
			where: `zone_no=${data.zone} AND street_no=${data.street}`,
			outFields: "zone_no,street_no,building_no,qars,pin",
			returnGeometry: "true",
			resultRecordCount: "200",
			orderByFields: "building_no"
		})).features ?? [];
		if (streetFeatures.length > 0) {
			let best = streetFeatures[0];
			let bestDelta = Number.POSITIVE_INFINITY;
			for (const feature of streetFeatures) {
				const n = feature.attributes?.building_no;
				if (typeof n !== "number") continue;
				const delta = Math.abs(n - data.building);
				if (delta < bestDelta) {
					best = feature;
					bestDelta = delta;
				}
			}
			const point = readPoint(best);
			if (point) return withPoint(base, point.lat, point.lng, {
				precision: "nearest",
				matchedBuilding: best.attributes?.building_no ?? null,
				qars: best.attributes?.qars ?? null,
				pin: best.attributes?.pin ?? null
			});
		}
		const ext = (await qarsQuery({
			where: `zone_no=${data.zone}`,
			returnExtentOnly: "true"
		})).extent;
		if (ext && typeof ext.xmin === "number" && typeof ext.xmax === "number" && typeof ext.ymin === "number" && typeof ext.ymax === "number") return withPoint(base, (ext.ymin + ext.ymax) / 2, (ext.xmin + ext.xmax) / 2, { precision: "zone" });
		return base;
	} catch {
		return emptyResult(data, "lookup_failed");
	}
});
//#endregion
export { lookupQatarAddress_createServerFn_handler };
