//#region node_modules/.nitro/vite/services/ssr/assets/format-DlqtK3md.js
var MUNICIPALITIES = {
	doha: {
		en: "Doha",
		ar: "الدوحة",
		fa: "دوحه"
	},
	rayyan: {
		en: "Al Rayyan",
		ar: "الريان",
		fa: "الریان"
	},
	daayen: {
		en: "Al Daayen",
		ar: "الضعاين",
		fa: "الضعاین"
	},
	"umm-salal": {
		en: "Umm Salal",
		ar: "أم صلال",
		fa: "ام صلال"
	},
	khor: {
		en: "Al Khor",
		ar: "الخور",
		fa: "الخور"
	},
	shamal: {
		en: "Al Shamal",
		ar: "الشمال",
		fa: "الشمال"
	},
	wakrah: {
		en: "Al Wakrah",
		ar: "الوكرة",
		fa: "الوکره"
	},
	shahaniya: {
		en: "Al Shahaniya",
		ar: "الشحانية",
		fa: "الشحانیه"
	}
};
var ZONES = [
	{
		n: 1,
		en: "Al Jasra",
		ar: "الجسرة",
		m: "doha"
	},
	{
		n: 2,
		en: "Al Bidda",
		ar: "البدع",
		m: "doha"
	},
	{
		n: 3,
		en: "Mushaireb",
		ar: "مشيرب",
		m: "doha"
	},
	{
		n: 4,
		en: "Mushaireb",
		ar: "مشيرب",
		m: "doha"
	},
	{
		n: 5,
		en: "Al Najada, Barahat Al Jufairi, Fereej Al Asmakh",
		ar: "النجادة، براحة الجفيري، فريج الأصمخ",
		m: "doha"
	},
	{
		n: 6,
		en: "Old Al Ghanim",
		ar: "الغانم العتيق",
		m: "doha"
	},
	{
		n: 7,
		en: "Al Souq",
		ar: "السوق",
		m: "doha"
	},
	{
		n: 10,
		en: "Wadi Al Sail",
		ar: "وادي السيل",
		m: "doha"
	},
	{
		n: 11,
		en: "Rumeilah",
		ar: "الرميلة",
		m: "doha"
	},
	{
		n: 12,
		en: "Al Bidda, Rumeilah, Wadi Al Sail",
		ar: "البدع، الرميلة، وادي السيل",
		m: "doha"
	},
	{
		n: 13,
		en: "Mushaireb",
		ar: "مشيرب",
		m: "doha"
	},
	{
		n: 14,
		en: "Fereej Abdel Aziz",
		ar: "فريج عبد العزيز",
		m: "doha"
	},
	{
		n: 15,
		en: "Doha Al Jadeeda",
		ar: "الدوحة الجديدة",
		m: "doha"
	},
	{
		n: 16,
		en: "Old Al Ghanim",
		ar: "الغانم العتيق",
		m: "doha"
	},
	{
		n: 17,
		en: "Al Rufaa, Al Hitmi",
		ar: "الرفاع، الهتمي",
		m: "doha"
	},
	{
		n: 18,
		en: "Al Mirqab, Salata",
		ar: "المرقاب، السلطة",
		m: "doha"
	},
	{
		n: 19,
		en: "Doha Port",
		ar: "ميناء الدوحة",
		m: "doha"
	},
	{
		n: 20,
		en: "Wadi Al Sail",
		ar: "وادي السيل",
		m: "doha"
	},
	{
		n: 21,
		en: "Rumeilah",
		ar: "الرميلة",
		m: "doha"
	},
	{
		n: 22,
		en: "Fereej Bin Mahmoud",
		ar: "فريج بن محمود",
		m: "doha"
	},
	{
		n: 23,
		en: "Fereej Bin Mahmoud",
		ar: "فريج بن محمود",
		m: "doha"
	},
	{
		n: 24,
		en: "Rawdat Al Khail",
		ar: "روضة الخيل",
		m: "doha"
	},
	{
		n: 25,
		en: "Al Mansoura, Fereej Bin Dirhem",
		ar: "المنصورة، فريج بن درهم",
		m: "doha"
	},
	{
		n: 26,
		en: "Najma",
		ar: "نجمة",
		m: "doha"
	},
	{
		n: 27,
		en: "Umm Ghuwailina",
		ar: "أم غويلينة",
		m: "doha"
	},
	{
		n: 28,
		en: "Al Khulaifat, Ras Bu Abboud",
		ar: "الخليفات، رأس بو عبود",
		m: "doha"
	},
	{
		n: 29,
		en: "Ras Bu Abboud",
		ar: "رأس بو عبود",
		m: "doha"
	},
	{
		n: 30,
		en: "Duhail",
		ar: "دحيل",
		m: "doha"
	},
	{
		n: 31,
		en: "Umm Lekhba",
		ar: "أم لخبا",
		m: "doha"
	},
	{
		n: 32,
		en: "Madinat Khalifa North, Dahl Al Hamam",
		ar: "مدينة خليفة الشمالية، دحل الحمام",
		m: "doha"
	},
	{
		n: 33,
		en: "Al Markhiya",
		ar: "المرخية",
		m: "doha"
	},
	{
		n: 34,
		en: "Madinat Khalifa South",
		ar: "مدينة خليفة الجنوبية",
		m: "doha"
	},
	{
		n: 35,
		en: "Fereej Kulaib",
		ar: "فريج كليب",
		m: "doha"
	},
	{
		n: 36,
		en: "Al Messila",
		ar: "المسيلة",
		m: "doha"
	},
	{
		n: 37,
		en: "Fereej Bin Omran, New Al Hitmi, Hamad Medical City",
		ar: "فريج بن عمران، الهتمي الجديد، مدينة حمد الطبية",
		m: "doha"
	},
	{
		n: 38,
		en: "Al Sadd",
		ar: "السد",
		m: "doha"
	},
	{
		n: 39,
		en: "Al Sadd, Al Nasr, Al Mirqab Al Jadeed",
		ar: "السد، النصر، المرقاب الجديد",
		m: "doha"
	},
	{
		n: 40,
		en: "New Salata",
		ar: "السلطة الجديدة",
		m: "doha"
	},
	{
		n: 41,
		en: "Nuaija",
		ar: "النعيجة",
		m: "doha"
	},
	{
		n: 42,
		en: "Al Hilal",
		ar: "الهلال",
		m: "doha"
	},
	{
		n: 43,
		en: "Al Maamoura, Nuaija",
		ar: "المعمورة، النعيجة",
		m: "doha"
	},
	{
		n: 44,
		en: "Nuaija",
		ar: "النعيجة",
		m: "doha"
	},
	{
		n: 45,
		en: "Old Airport",
		ar: "المطار القديم",
		m: "doha"
	},
	{
		n: 46,
		en: "Al Thumama",
		ar: "الثمامة",
		m: "doha"
	},
	{
		n: 47,
		en: "Al Thumama",
		ar: "الثمامة",
		m: "doha"
	},
	{
		n: 48,
		en: "Doha International Airport",
		ar: "مطار الدوحة الدولي",
		m: "doha"
	},
	{
		n: 49,
		en: "Hamad International Airport, Banana Island, Ras Bu Fontas",
		ar: "مطار حمد الدولي، جزيرة اللؤلؤة الموز، رأس بو فنطاس",
		m: "doha"
	},
	{
		n: 50,
		en: "Al Thumama",
		ar: "الثمامة",
		m: "doha"
	},
	{
		n: 51,
		en: "Al Gharrafa, Izghawa, Bani Hajer",
		ar: "الغرافة، ازغوى، بني هاجر",
		m: "rayyan"
	},
	{
		n: 52,
		en: "Al Luqta, Old Al Rayyan, Education City",
		ar: "اللقطة، الريان العتيق، المدينة التعليمية",
		m: "rayyan"
	},
	{
		n: 53,
		en: "New Al Rayyan, Al Wajba, Muaither",
		ar: "الريان الجديد، الوجبة، معيذر",
		m: "rayyan"
	},
	{
		n: 54,
		en: "Fereej Al Amir, Luaib, Aspire Zone",
		ar: "فريج الأمير، لوعيب، أسباير",
		m: "rayyan"
	},
	{
		n: 55,
		en: "Al Waab, Al Aziziya, Fereej Al Soudan",
		ar: "الوعب، العزيزية، فريج السودان",
		m: "rayyan"
	},
	{
		n: 56,
		en: "Ain Khaled, Mesaimeer, Abu Hamour",
		ar: "عين خالد، مسيمير، أبو هامور",
		m: "rayyan"
	},
	{
		n: 57,
		en: "Industrial Area",
		ar: "المنطقة الصناعية",
		m: "doha"
	},
	{
		n: 58,
		en: "Wholesale Market",
		ar: "السوق المركزي",
		m: "doha"
	},
	{
		n: 60,
		en: "Al Dafna",
		ar: "الدفنة",
		m: "doha"
	},
	{
		n: 61,
		en: "Al Dafna, Al Gassar",
		ar: "الدفنة، القصار",
		m: "doha"
	},
	{
		n: 62,
		en: "Lekhwair",
		ar: "لخوير",
		m: "doha"
	},
	{
		n: 63,
		en: "Onaiza",
		ar: "عنيزة",
		m: "doha"
	},
	{
		n: 64,
		en: "Lejbailat",
		ar: "الجبيلات",
		m: "doha"
	},
	{
		n: 65,
		en: "Onaiza",
		ar: "عنيزة",
		m: "doha"
	},
	{
		n: 66,
		en: "The Pearl, Legtaifiya, Katara",
		ar: "اللؤلؤة، لقطيفية، كتارا",
		m: "doha"
	},
	{
		n: 67,
		en: "Hazm Al Markhiya",
		ar: "حزم المرخية",
		m: "doha"
	},
	{
		n: 68,
		en: "Jelaiah, Al Tarfa, Jeryan Nejaima",
		ar: "الجليعة، الطرفة، جريان نجيمة",
		m: "doha"
	},
	{
		n: 69,
		en: "Lusail, Al Egla, Jabal Thuaileb",
		ar: "لوسيل، الإقلة، جبل ثعيلب",
		m: "daayen"
	},
	{
		n: 70,
		en: "Al Ebb, Al Kheesa, Umm Qarn, Al Daayen",
		ar: "العب، الخيسة، أم قرن، الضعاين",
		m: "daayen"
	},
	{
		n: 71,
		en: "Umm Salal Ali, Umm Salal Mohammed, Al Kharaitiyat",
		ar: "أم صلال علي، أم صلال محمد، الخريطيات",
		m: "umm-salal"
	},
	{
		n: 72,
		en: "Al Utouriya",
		ar: "العطورية",
		m: "shahaniya"
	},
	{
		n: 73,
		en: "Al Jemailiya",
		ar: "الجميلية",
		m: "shahaniya"
	},
	{
		n: 74,
		en: "Al Khor, Simaisma",
		ar: "الخور، سميسمة",
		m: "khor"
	},
	{
		n: 75,
		en: "Al Thakhira, Ras Laffan",
		ar: "الذخيرة، رأس لفان",
		m: "khor"
	},
	{
		n: 76,
		en: "Al Ghuwariyah",
		ar: "الغويرية",
		m: "khor"
	},
	{
		n: 77,
		en: "Ain Sinan, Fuwayrit, Madinat Al Kaaban",
		ar: "عين سنان، فويرط، مدينة الكعبان",
		m: "shamal"
	},
	{
		n: 78,
		en: "Zubarah, Abu Dhalouf",
		ar: "الزبارة، أبو ظلوف",
		m: "shamal"
	},
	{
		n: 79,
		en: "Madinat Al Shamal, Al Ruwais",
		ar: "مدينة الشمال، الرويس",
		m: "shamal"
	},
	{
		n: 80,
		en: "Al Shahaniya City",
		ar: "مدينة الشحانية",
		m: "shahaniya"
	},
	{
		n: 81,
		en: "Mebaireek",
		ar: "مبيريك",
		m: "rayyan"
	},
	{
		n: 82,
		en: "Rawdat Rashed",
		ar: "روضة راشد",
		m: "shahaniya"
	},
	{
		n: 83,
		en: "Al Karaana",
		ar: "الكرعانة",
		m: "rayyan"
	},
	{
		n: 84,
		en: "Umm Bab",
		ar: "أم باب",
		m: "shahaniya"
	},
	{
		n: 85,
		en: "Al Nasraniya",
		ar: "النصرانية",
		m: "shahaniya"
	},
	{
		n: 86,
		en: "Dukhan",
		ar: "دخان",
		m: "shahaniya"
	},
	{
		n: 90,
		en: "Al Wakrah",
		ar: "الوكرة",
		m: "wakrah"
	},
	{
		n: 91,
		en: "Al Wukair, Al Mashaf, Al Thumama",
		ar: "الوكير، المشاف، الثمامة",
		m: "wakrah"
	},
	{
		n: 92,
		en: "Mesaieed",
		ar: "مسيعيد",
		m: "wakrah"
	},
	{
		n: 93,
		en: "Mesaieed Industrial Area",
		ar: "منطقة مسيعيد الصناعية",
		m: "wakrah"
	},
	{
		n: 94,
		en: "Shagra",
		ar: "شقرا",
		m: "wakrah"
	},
	{
		n: 95,
		en: "Al Kharrara",
		ar: "الخرارة",
		m: "wakrah"
	},
	{
		n: 96,
		en: "Abu Samra",
		ar: "أبو سمرة",
		m: "rayyan"
	},
	{
		n: 97,
		en: "Sawda Natheel",
		ar: "سودة نثيل",
		m: "rayyan"
	},
	{
		n: 98,
		en: "Khor Al Adaid",
		ar: "خور العديد",
		m: "wakrah"
	}
];
var ZONE_BY_NUMBER = new Map(ZONES.map((z) => [z.n, z]));
function getZone(n) {
	return ZONE_BY_NUMBER.get(n);
}
function searchZones(query) {
	const q = query.trim().toLowerCase();
	if (!q) return [];
	const asNum = Number(q);
	if (Number.isInteger(asNum)) {
		const hit = ZONE_BY_NUMBER.get(asNum);
		return hit ? [hit] : [];
	}
	return ZONES.filter((z) => z.en.toLowerCase().includes(q) || z.ar.includes(query.trim()) || MUNICIPALITIES[z.m].en.toLowerCase().includes(q) || MUNICIPALITIES[z.m].ar.includes(query.trim()) || MUNICIPALITIES[z.m].fa.includes(query.trim())).slice(0, 8);
}
function formattedAddress(q, locale) {
	const zone = getZone(q.zone);
	const muni = zone ? MUNICIPALITIES[zone.m] : void 0;
	if (locale === "en") {
		const district = zone?.en ?? `Zone ${q.zone}`;
		const city = muni?.en ?? "Qatar";
		return `Building ${q.building}, Street ${q.street}, Zone ${q.zone}, ${district}, ${city}, Qatar`;
	}
	const district = zone?.ar ?? String(q.zone);
	const city = muni?.ar ?? "قطر";
	return `مبنى ${q.building}، شارع ${q.street}، منطقة ${q.zone}، ${district}، ${city}، قطر`;
}
function googleSearchUrl(query, lat, lng) {
	if (lat != null && lng != null) return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
	return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}
function googleNavUrl(lat, lng) {
	return `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=driving`;
}
function wazeUrl(lat, lng, query) {
	if (lat != null && lng != null) return `https://waze.com/ul?ll=${lat},${lng}&navigate=yes&zoom=17`;
	return `https://waze.com/ul?q=${encodeURIComponent(query ?? "")}&navigate=yes`;
}
function formatCoords(lat, lng) {
	return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
}
function parsePlateNumber(raw) {
	const digits = raw.replace(/[^\d]/g, "");
	if (!digits) return "";
	const n = Number(digits);
	if (!Number.isFinite(n) || n < 0) return "";
	return n;
}
//#endregion
export { googleNavUrl as a, searchZones as c, getZone as i, wazeUrl as l, formatCoords as n, googleSearchUrl as o, formattedAddress as r, parsePlateNumber as s, MUNICIPALITIES as t };
