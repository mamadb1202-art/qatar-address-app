import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { c as searchZones, i as getZone, n as formatCoords, s as parsePlateNumber, t as MUNICIPALITIES } from "./format-DlqtK3md.mjs";
import { a as MapPinned, i as Navigation, n as Share2, o as LoaderCircle, r as Search, s as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route } from "./router-DltOhkjP.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-RMs7HDff.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-(--motion-quick) ease-(--ease-out) focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98] [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg shadow-border hover:opacity-95",
			outline: "bg-surface text-fg shadow-border hover:shadow-border-hover",
			ghost: "text-fg hover:bg-surface-muted",
			soft: "bg-primary/8 text-primary hover:bg-primary/12"
		},
		size: {
			default: "h-11 min-h-11 px-4",
			sm: "h-9 min-h-9 px-3 text-xs",
			lg: "h-12 min-h-12 px-5 text-base",
			icon: "size-11 min-h-11 min-w-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-lg bg-surface px-3 text-sm text-fg shadow-border outline-none", "placeholder:text-subtle", "focus-visible:ring-2 focus-visible:ring-primary/35", className),
		...props
	});
}
var LOCALES = [
	{
		id: "fa",
		label: "فا"
	},
	{
		id: "ar",
		label: "ع"
	},
	{
		id: "en",
		label: "EN"
	}
];
var STRINGS = {
	fa: {
		appName: "آدرس قطر",
		tagline: "شماره پلاک آبی را بزن؛ موقعیت، گوگل مپ و ویز را بگیر",
		zone: "منطقه",
		street: "خیابان",
		building: "ساختمان",
		find: "پیدا کردن موقعیت",
		finding: "در حال جستجو…",
		google: "گوگل مپ",
		waze: "ویز",
		navigateGoogle: "مسیر با گوگل مپ",
		navigateWaze: "مسیر با ویز",
		copyAddress: "کپی آدرس",
		copyCoords: "کپی مختصات",
		copyLinks: "کپی لینک‌ها",
		share: "اشتراک",
		recent: "جستجوهای اخیر",
		searchDistrict: "جستجوی محله",
		searchPlaceholder: "مثلاً السد، الوعب، لوسیل",
		notFound: "این پلاک در سامانه آدرس قطر پیدا نشد. لینک جستجوی گوگل مپ و ویز ساخته شد.",
		nearest: "ساختمان دقیق نبود؛ نزدیک‌ترین پلاک همین خیابان نشان داده شد.",
		streetLevel: "موقعیت تقریبی خیابان",
		zoneLevel: "موقعیت تقریبی منطقه",
		exact: "موقعیت دقیق ساختمان",
		copied: "کپی شد",
		example: "نمونه",
		coords: "مختصات",
		address: "آدرس",
		satellite: "ماهواره",
		mapView: "نقشه",
		plateHint: "همان اعداد روی پلاک آبی إنواني",
		openMaps: "باز کردن نقشه",
		noRecent: "هنوز جستجویی نشده",
		lookupFailed: "اتصال به سامانه آدرس قطر برقرار نشد. لینک‌های جستجو آماده است.",
		required: "هر سه شماره لازم است",
		pin: "پین",
		qars: "کد آدرس",
		trySample: "امتحان با نمونه السد",
		clear: "پاک کردن",
		district: "محله"
	},
	ar: {
		appName: "عنوان قطر",
		tagline: "أدخل أرقام اللوحة الزرقاء لتحصل على الموقع وخرائط جوجل وويز",
		zone: "المنطقة",
		street: "الشارع",
		building: "المبنى",
		find: "إيجاد الموقع",
		finding: "جاري البحث…",
		google: "خرائط جوجل",
		waze: "ويز",
		navigateGoogle: "التوجيه عبر جوجل",
		navigateWaze: "التوجيه عبر ويز",
		copyAddress: "نسخ العنوان",
		copyCoords: "نسخ الإحداثيات",
		copyLinks: "نسخ الروابط",
		share: "مشاركة",
		recent: "عمليات البحث الأخيرة",
		searchDistrict: "البحث عن الحي",
		searchPlaceholder: "مثلاً السد، الوعب، لوسيل",
		notFound: "لم يُعثر على هذا الرقم في نظام العنوان الوطني. تم إنشاء روابط البحث.",
		nearest: "المبنى غير مطابق؛ أقرب مبنى في الشارع نفسه.",
		streetLevel: "موقع تقريبي للشارع",
		zoneLevel: "موقع تقريبي للمنطقة",
		exact: "موقع المبنى بدقة",
		copied: "تم النسخ",
		example: "مثال",
		coords: "الإحداثيات",
		address: "العنوان",
		satellite: "قمر صناعي",
		mapView: "خريطة",
		plateHint: "الأرقام نفسها على لوحة إنواني الزرقاء",
		openMaps: "فتح الخريطة",
		noRecent: "لا توجد عمليات بحث بعد",
		lookupFailed: "تعذر الاتصال بنظام العنوان. روابط البحث جاهزة.",
		required: "الأرقام الثلاثة مطلوبة",
		pin: "الرمز",
		qars: "رمز العنوان",
		trySample: "تجربة مثال السد",
		clear: "مسح",
		district: "الحي"
	},
	en: {
		appName: "Qatar Address",
		tagline: "Enter the blue plate numbers to get the pin, Google Maps, and Waze",
		zone: "Zone",
		street: "Street",
		building: "Building",
		find: "Find location",
		finding: "Searching…",
		google: "Google Maps",
		waze: "Waze",
		navigateGoogle: "Navigate with Google",
		navigateWaze: "Navigate with Waze",
		copyAddress: "Copy address",
		copyCoords: "Copy coordinates",
		copyLinks: "Copy links",
		share: "Share",
		recent: "Recent searches",
		searchDistrict: "Search district",
		searchPlaceholder: "e.g. Al Sadd, Al Waab, Lusail",
		notFound: "This plate was not in the national address system. Search links are ready.",
		nearest: "Exact building missing; showing the closest building on this street.",
		streetLevel: "Approximate street location",
		zoneLevel: "Approximate zone location",
		exact: "Exact building location",
		copied: "Copied",
		example: "Sample",
		coords: "Coordinates",
		address: "Address",
		satellite: "Satellite",
		mapView: "Map",
		plateHint: "The numbers on the blue Inwani plate",
		openMaps: "Open map",
		noRecent: "No searches yet",
		lookupFailed: "Could not reach the address service. Search links are ready.",
		required: "All three numbers are required",
		pin: "PIN",
		qars: "Address code",
		trySample: "Try Al Sadd sample",
		clear: "Clear",
		district: "District"
	}
};
function localeDir(locale) {
	return locale === "en" ? "ltr" : "rtl";
}
function localeLang(locale) {
	return locale;
}
function ResultMap({ lat, lng, label, locale }) {
	const containerRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const layersRef = (0, import_react.useRef)({});
	const [satellite, setSatellite] = (0, import_react.useState)(true);
	const t = STRINGS[locale];
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		if (!containerRef.current) return;
		(async () => {
			const leaflet = await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			const L = leaflet.default ?? leaflet;
			if (cancelled || !containerRef.current) return;
			if (mapRef.current) {
				mapRef.current.remove();
				mapRef.current = null;
			}
			const map = L.map(containerRef.current, {
				zoomControl: false,
				attributionControl: true
			}).setView([lat, lng], 18);
			const streets = L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
				attribution: "&copy; OpenStreetMap &copy; CARTO",
				maxZoom: 20,
				subdomains: "abcd"
			});
			const imagery = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
				attribution: "Tiles &copy; Esri",
				maxZoom: 19
			});
			imagery.addTo(map);
			L.control.zoom({ position: "topright" }).addTo(map);
			const icon = L.divIcon({
				className: "inwani-marker",
				html: `<span class="inwani-marker-dot" title="${label}"></span>`,
				iconSize: [28, 28],
				iconAnchor: [14, 14]
			});
			const marker = L.marker([lat, lng], {
				icon,
				title: label
			}).addTo(map);
			mapRef.current = map;
			layersRef.current = {
				streets,
				satellite: imagery,
				marker
			};
			requestAnimationFrame(() => map.invalidateSize());
			window.setTimeout(() => map.invalidateSize(), 250);
		})();
		return () => {
			cancelled = true;
			mapRef.current?.remove();
			mapRef.current = null;
		};
	}, [
		lat,
		lng,
		label
	]);
	(0, import_react.useEffect)(() => {
		const map = mapRef.current;
		const { streets, satellite: imagery } = layersRef.current;
		if (!map || !streets || !imagery) return;
		if (satellite) {
			if (map.hasLayer(streets)) map.removeLayer(streets);
			if (!map.hasLayer(imagery)) imagery.addTo(map);
		} else {
			if (map.hasLayer(imagery)) map.removeLayer(imagery);
			if (!map.hasLayer(streets)) streets.addTo(map);
		}
	}, [satellite]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative overflow-hidden rounded-xl bg-surface-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: containerRef,
			className: "h-72 w-full md:h-96"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute start-3 top-3 z-10 flex gap-1 rounded-lg bg-surface/92 p-1 shadow-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setSatellite(true),
				className: cn("h-9 rounded-md px-3 text-xs font-medium", satellite ? "bg-primary text-primary-fg" : "text-muted hover:text-fg"),
				children: t.satellite
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setSatellite(false),
				className: cn("h-9 rounded-md px-3 text-xs font-medium", !satellite ? "bg-primary text-primary-fg" : "text-muted hover:text-fg"),
				children: t.mapView
			})]
		})]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var lookupQatarAddress = createServerFn({ method: "GET" }).validator((raw) => {
	const data = raw ?? {};
	const zone = Number(data.zone);
	const street = Number(data.street);
	const building = Number(data.building);
	if (!Number.isInteger(zone) || zone < 1 || zone > 99) throw new Error("Invalid zone");
	if (!Number.isInteger(street) || street < 1 || street > 9999) throw new Error("Invalid street");
	if (!Number.isInteger(building) || building < 1 || building > 9999) throw new Error("Invalid building");
	return {
		zone,
		street,
		building
	};
}).handler(createSsrRpc("0378ddf04db7b73a7eb4c8c6c32be72c340306ac9b25067ee3c492c3ccbd58cf"));
var LOCALE_KEY = "inwani-locale";
var RECENT_KEY = "inwani-recent-v1";
var SAMPLE = {
	zone: 38,
	street: 343,
	building: 12
};
function readLocale() {
	if (typeof window === "undefined") return "fa";
	const stored = window.localStorage.getItem(LOCALE_KEY);
	if (stored === "fa" || stored === "ar" || stored === "en") return stored;
	const langs = window.navigator.languages ?? [window.navigator.language];
	if (langs.some((l) => l.toLowerCase().startsWith("fa"))) return "fa";
	if (langs.some((l) => l.toLowerCase().startsWith("ar"))) return "ar";
	return "fa";
}
function readRecent() {
	try {
		const raw = localStorage.getItem(RECENT_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed.slice(0, 8) : [];
	} catch {
		return [];
	}
}
function saveRecent(item) {
	const next = [item, ...readRecent().filter((r) => !(r.zone === item.zone && r.street === item.street && r.building === item.building))].slice(0, 8);
	localStorage.setItem(RECENT_KEY, JSON.stringify(next));
	return next;
}
function districtLabel(zone, locale) {
	if (!zone) return "";
	const muni = MUNICIPALITIES[zone.m];
	if (locale === "en") return `${zone.en} · ${muni.en}`;
	if (locale === "fa") return `${zone.ar} · ${muni.fa}`;
	return `${zone.ar} · ${muni.ar}`;
}
function precisionMessage(result, locale) {
	const t = STRINGS[locale];
	if (result.error === "lookup_failed") return t.lookupFailed;
	if (result.precision === "building") return t.exact;
	if (result.precision === "nearest") return result.matchedBuilding ? `${t.nearest} (${result.matchedBuilding})` : t.nearest;
	if (result.precision === "street") return t.streetLevel;
	if (result.precision === "zone") return t.zoneLevel;
	return t.notFound;
}
function AddressApp({ initial }) {
	const navigate = useNavigate({ from: "/" });
	const [locale, setLocale] = (0, import_react.useState)("fa");
	const [zone, setZone] = (0, import_react.useState)(initial.z ?? "");
	const [street, setStreet] = (0, import_react.useState)(initial.s ?? "");
	const [building, setBuilding] = (0, import_react.useState)(initial.b ?? "");
	const [districtQuery, setDistrictQuery] = (0, import_react.useState)("");
	const [result, setResult] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [recent, setRecent] = (0, import_react.useState)([]);
	const didAuto = (0, import_react.useRef)(false);
	const t = STRINGS[locale];
	const dir = localeDir(locale);
	(0, import_react.useEffect)(() => {
		setLocale(readLocale());
		setRecent(readRecent());
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = localeLang(locale);
		document.documentElement.dir = dir;
		localStorage.setItem(LOCALE_KEY, locale);
	}, [locale, dir]);
	const zoneMeta = typeof zone === "number" ? getZone(zone) : void 0;
	const districtMatches = (0, import_react.useMemo)(() => districtQuery.trim().length >= 2 ? searchZones(districtQuery) : [], [districtQuery]);
	async function runLookup(q) {
		setLoading(true);
		try {
			const found = await lookupQatarAddress({ data: q });
			setResult(found);
			const zoneInfo = getZone(q.zone);
			setRecent(saveRecent({
				...q,
				label: zoneInfo ? locale === "en" ? zoneInfo.en : zoneInfo.ar : `Zone ${q.zone}`
			}));
			await navigate({
				search: {
					z: q.zone,
					s: q.street,
					b: q.building
				},
				replace: true
			});
		} catch {
			toast.error(STRINGS[locale].lookupFailed);
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		if (didAuto.current) return;
		if (initial.z && initial.s && initial.b) {
			didAuto.current = true;
			runLookup({
				zone: initial.z,
				street: initial.s,
				building: initial.b
			});
		}
	}, []);
	function onSubmit(e) {
		e.preventDefault();
		if (zone === "" || street === "" || building === "") {
			toast.error(t.required);
			return;
		}
		runLookup({
			zone,
			street,
			building
		});
	}
	function fill(q) {
		setZone(q.zone);
		setStreet(q.street);
		setBuilding(q.building);
		runLookup(q);
	}
	async function copyText(value) {
		try {
			await navigator.clipboard.writeText(value);
			toast.success(t.copied);
		} catch {
			toast.error(t.copied);
		}
	}
	async function shareResult(found) {
		const text = [
			locale === "en" ? found.formattedEn : found.formattedAr,
			found.lat != null && found.lng != null ? formatCoords(found.lat, found.lng) : "",
			found.googleSearchUrl,
			found.wazeUrl
		].filter(Boolean).join("\n");
		if (navigator.share) try {
			await navigator.share({
				title: t.appName,
				text
			});
			return;
		} catch {}
		await copyText(text);
	}
	const shareLinks = result != null ? `${result.googleSearchUrl}\n${result.wazeUrl}` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-bg text-fg",
		dir,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-lg flex-col gap-6 px-4 py-6 pb-16 md:max-w-2xl md:py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-wide text-muted",
								children: "Inwani · إنواني"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-1 text-3xl font-semibold tracking-tight text-fg md:text-4xl",
								children: t.appName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-md text-sm leading-relaxed text-muted",
								children: t.tagline
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex shrink-0 rounded-lg bg-surface p-1 shadow-border",
						children: LOCALES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setLocale(item.id),
							className: cn("h-9 min-w-9 rounded-md px-2.5 text-xs font-medium", locale === item.id ? "bg-primary text-primary-fg" : "text-muted hover:text-fg"),
							children: item.label
						}, item.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-3xl bg-plate p-3 text-plate-fg shadow-plate",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between px-2 pt-1 text-xs font-medium uppercase tracking-wide text-plate-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "State of Qatar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "دولة قطر" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlateField, {
											label: t.zone,
											hint: "Zone",
											value: zone,
											onChange: setZone,
											autoFocus: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlateField, {
											label: t.street,
											hint: "Street",
											value: street,
											onChange: setStreet
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlateField, {
											label: t.building,
											hint: "Building",
											value: building,
											onChange: setBuilding
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 px-2 pb-1 text-center text-xs text-plate-muted",
									children: t.plateHint
								})
							]
						}),
						zoneMeta ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-medium text-fg",
								children: [t.district, ": "]
							}), districtLabel(zoneMeta, locale)]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex flex-col gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-medium text-muted",
									children: t.searchDistrict
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: districtQuery,
										onChange: (e) => setDistrictQuery(e.target.value),
										placeholder: t.searchPlaceholder,
										className: "ps-10",
										autoComplete: "off"
									})]
								}),
								districtMatches.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "overflow-hidden rounded-xl bg-surface shadow-border",
									children: districtMatches.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											setZone(item.n);
											setDistrictQuery("");
										},
										className: "flex w-full items-center justify-between gap-3 px-3 py-3 text-start hover:bg-surface-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "min-w-0 truncate text-sm",
											children: locale === "en" ? item.en : item.ar
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "shrink-0 text-xs tabular-nums text-muted",
											children: [
												t.zone,
												" ",
												item.n
											]
										})]
									}) }, item.n))
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							size: "lg",
							disabled: loading,
							className: "w-full",
							children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPinned, {}), loading ? t.finding : t.find]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "soft",
								size: "sm",
								onClick: () => fill(SAMPLE),
								children: t.trySample
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "sm",
								onClick: () => {
									setZone("");
									setStreet("");
									setBuilding("");
									setResult(null);
									navigate({
										search: {},
										replace: true
									});
								},
								children: t.clear
							})]
						})
					]
				}),
				result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-4 rounded-3xl bg-surface p-3 shadow-border md:p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-1 pt-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("text-xs font-medium", result.precision === "building" ? "text-ok" : result.precision === "none" ? "text-danger" : "text-warn"),
									children: precisionMessage(result, locale)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-lg font-semibold leading-snug",
									children: locale === "en" ? result.formattedEn : result.formattedAr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: locale === "en" ? result.formattedAr : result.formattedEn
								})
							]
						}),
						result.lat != null && result.lng != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultMap, {
							lat: result.lat,
							lng: result.lng,
							label: result.formattedEn,
							locale
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-40 items-center justify-center rounded-xl bg-surface-muted px-6 text-center text-sm text-muted",
							children: t.openMaps
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: result.googleSearchUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "inline-flex h-12 min-h-12 items-center justify-center gap-2 rounded-lg bg-primary px-3 text-sm font-medium text-primary-fg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPinned, { className: "size-4" }), t.google]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: result.wazeUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "inline-flex h-12 min-h-12 items-center justify-center gap-2 rounded-lg bg-surface text-sm font-medium text-fg shadow-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "size-4" }), t.waze]
								}),
								result.googleNavUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: result.googleNavUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "inline-flex h-11 min-h-11 items-center justify-center gap-2 rounded-lg bg-primary/8 px-3 text-sm font-medium text-primary",
									children: t.navigateGoogle
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: result.wazeUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "col-span-2 inline-flex h-11 min-h-11 items-center justify-center gap-2 rounded-lg bg-primary/8 px-3 text-sm font-medium text-primary sm:col-span-1",
									children: t.navigateWaze
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid grid-cols-1 gap-3 px-1 text-sm md:grid-cols-2",
							children: [result.lat != null && result.lng != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-muted",
								children: t.coords
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-0.5 font-medium tabular-nums",
								children: formatCoords(result.lat, result.lng)
							})] }) : null, result.qars ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-muted",
								children: t.qars
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-0.5 font-medium tabular-nums",
								children: result.qars
							})] }) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "outline",
									size: "sm",
									onClick: () => copyText(locale === "en" ? result.formattedEn : result.formattedAr),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), t.copyAddress]
								}),
								result.lat != null && result.lng != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "outline",
									size: "sm",
									onClick: () => copyText(formatCoords(result.lat, result.lng)),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), t.copyCoords]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "outline",
									size: "sm",
									onClick: () => copyText(shareLinks),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), t.copyLinks]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "outline",
									size: "sm",
									onClick: () => void shareResult(result),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {}), t.share]
								})
							]
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium text-muted",
						children: t.recent
					}), recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-subtle",
						children: t.noRecent
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: recent.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => fill(item),
							className: "flex w-full items-center justify-between gap-3 rounded-xl bg-surface px-4 py-3 text-start shadow-border hover:shadow-border-hover",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm font-medium",
									children: item.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-0.5 block text-xs tabular-nums text-muted",
									children: [
										t.zone,
										" ",
										item.zone,
										" · ",
										t.street,
										" ",
										item.street,
										" · ",
										t.building,
										" ",
										item.building
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPinned, { className: "size-4 shrink-0 text-subtle" })]
						}) }, `${item.zone}-${item.street}-${item.building}`))
					})]
				})
			]
		})
	});
}
function PlateField({ label, hint, value, onChange, autoFocus }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1.5 rounded-xl bg-plate-fg/10 px-2 py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-center text-xs font-medium text-plate-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				inputMode: "numeric",
				pattern: "[0-9]*",
				autoFocus,
				value,
				onChange: (e) => onChange(parsePlateNumber(e.target.value)),
				className: "h-14 w-full bg-transparent text-center text-3xl font-semibold tabular-nums text-plate-fg outline-none md:text-4xl",
				"aria-label": label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-center text-xs uppercase tracking-wide text-plate-muted",
				children: hint
			})
		]
	});
}
function Home() {
	const search = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddressApp, { initial: search });
}
//#endregion
export { Home as component };
