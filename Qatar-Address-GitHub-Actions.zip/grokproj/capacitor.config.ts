import { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.essabalouchi.qataraddress",
  appName: "Qatar Address",
  webDir: "android-web",
  bundledWebRuntime: false,
  server: {
    androidScheme: "https",
  },
};

export default config;
