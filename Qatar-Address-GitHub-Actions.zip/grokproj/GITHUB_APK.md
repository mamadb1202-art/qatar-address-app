# ساخت APK با GitHub Actions

این پروژه برای ساخت APK اندروید بدون Android Studio آماده شده است.

## روش استفاده

1. کل پروژه را در یک Repository در GitHub قرار بده.
2. به بخش **Actions** برو.
3. Workflow با نام **Build Android APK** را انتخاب کن.
4. روی **Run workflow** بزن.
5. بعد از اتمام Build، وارد همان Run شو.
6. در بخش **Artifacts** فایل `Qatar-Address-debug-apk` را دریافت کن.
7. فایل `app-debug.apk` را روی گوشی اندرویدی نصب کن.

## نکته مهم

این APK نسخه Debug است و برای نصب مستقیم و تست مناسب است. برای انتشار در Google Play باید بعداً APK/AAB را با کلید امضای اختصاصی Sign کرد.

در نسخه Android، جست‌وجوی آدرس مستقیماً از سرویس Qatar Address Reference System انجام می‌شود و به سرور Node.js پروژه وابسته نیست.
